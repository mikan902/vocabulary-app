// 認証管理
class Auth {
    constructor() {
        this.isHost = false;
        this.loadHostStatus();
    }

    // ローカルストレージからホスト状態を読み込み
    loadHostStatus() {
        const saved = localStorage.getItem('isHost');
        this.isHost = saved === 'true';
        this.updateUI();
    }

    // ホスト状態を保存
    saveHostStatus(isHost) {
        this.isHost = isHost;
        localStorage.setItem('isHost', isHost.toString());
        this.updateUI();
        
        // サーバーにも保存を試みる
        api.saveHostStatus(isHost).catch(err => {
            console.warn('Failed to save host status to server:', err);
        });
    }

    // 管理者コードの確認
    verifyAdminCode(code) {
        return code === ADMIN_CODE;
    }

    // UIの更新
    updateUI() {
        const userStatus = document.getElementById('userStatus');
        const adminBtn = document.getElementById('adminBtn');
        const wordScope = document.getElementById('wordScope');

        if (this.isHost) {
            userStatus.textContent = '管理者モード';
            userStatus.style.background = 'rgba(255, 215, 0, 0.3)';
            adminBtn.textContent = 'ゲストに戻る';
            
            // 共有単語の追加を有効化
            if (wordScope) {
                const sharedOption = wordScope.querySelector('option[value="shared"]');
                if (sharedOption) {
                    sharedOption.disabled = false;
                }
            }
        } else {
            userStatus.textContent = 'ゲストモード';
            userStatus.style.background = 'rgba(255, 255, 255, 0.2)';
            adminBtn.textContent = '管理者になる';
            
            // 共有単語の追加を無効化
            if (wordScope) {
                const sharedOption = wordScope.querySelector('option[value="shared"]');
                if (sharedOption) {
                    sharedOption.disabled = true;
                }
                wordScope.value = 'private';
            }
        }
    }

    // 管理者モーダルの表示
    showAdminModal() {
        if (this.isHost) {
            // すでに管理者の場合はゲストに戻す
            if (confirm('ゲストモードに戻りますか？')) {
                this.saveHostStatus(false);
            }
        } else {
            // ゲストの場合は管理コード入力
            const modal = document.getElementById('adminModal');
            modal.classList.add('active');
            document.getElementById('adminCode').value = '';
            document.getElementById('adminCode').focus();
        }
    }

    // 管理者コードの送信
    submitAdminCode() {
        const code = document.getElementById('adminCode').value;
        
        if (this.verifyAdminCode(code)) {
            this.saveHostStatus(true);
            this.closeAdminModal();
            alert('管理者モードになりました');
        } else {
            alert('管理コードが正しくありません');
            document.getElementById('adminCode').value = '';
            document.getElementById('adminCode').focus();
        }
    }

    // モーダルを閉じる
    closeAdminModal() {
        const modal = document.getElementById('adminModal');
        modal.classList.remove('active');
    }
}

// グローバルインスタンス
const auth = new Auth();

// イベントリスナー
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('adminBtn').addEventListener('click', () => {
        auth.showAdminModal();
    });

    document.getElementById('submitAdminCode').addEventListener('click', () => {
        auth.submitAdminCode();
    });

    document.getElementById('cancelAdminModal').addEventListener('click', () => {
        auth.closeAdminModal();
    });

    // Enterキーで送信
    document.getElementById('adminCode').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            auth.submitAdminCode();
        }
    });
});
