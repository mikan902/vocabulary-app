// API通信（共有単語用）
class API {
    constructor() {
        this.baseUrl = 'tables';
    }

    // 共有単語の取得
    async getSharedWords() {
        try {
            const response = await fetch(`${this.baseUrl}/shared_words?limit=1000`);
            if (!response.ok) throw new Error('Failed to fetch shared words');
            const data = await response.json();
            return data.data || [];
        } catch (error) {
            console.error('Error fetching shared words:', error);
            return [];
        }
    }

    // 共有単語の追加（ホストのみ）
    async addSharedWord(word) {
        try {
            const response = await fetch(`${this.baseUrl}/shared_words`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(word)
            });
            if (!response.ok) throw new Error('Failed to add shared word');
            return await response.json();
        } catch (error) {
            console.error('Error adding shared word:', error);
            throw error;
        }
    }

    // 共有単語の更新（ホストのみ）
    async updateSharedWord(id, word) {
        try {
            const response = await fetch(`${this.baseUrl}/shared_words/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(word)
            });
            if (!response.ok) throw new Error('Failed to update shared word');
            return await response.json();
        } catch (error) {
            console.error('Error updating shared word:', error);
            throw error;
        }
    }

    // 共有単語の削除（ホストのみ）
    async deleteSharedWord(id) {
        try {
            const response = await fetch(`${this.baseUrl}/shared_words/${id}`, {
                method: 'DELETE'
            });
            if (!response.ok) throw new Error('Failed to delete shared word');
        } catch (error) {
            console.error('Error deleting shared word:', error);
            throw error;
        }
    }

    // ホストステータスの取得
    async getHostStatus() {
        try {
            const response = await fetch(`${this.baseUrl}/host_status?limit=1`);
            if (!response.ok) return null;
            const data = await response.json();
            return data.data && data.data.length > 0 ? data.data[0] : null;
        } catch (error) {
            console.error('Error fetching host status:', error);
            return null;
        }
    }

    // ホストステータスの保存
    async saveHostStatus(isHost) {
        try {
            const existing = await this.getHostStatus();
            const statusData = {
                isHost: isHost,
                lastLogin: Date.now()
            };

            if (existing) {
                const response = await fetch(`${this.baseUrl}/host_status/${existing.id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(statusData)
                });
                return await response.json();
            } else {
                const response = await fetch(`${this.baseUrl}/host_status`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(statusData)
                });
                return await response.json();
            }
        } catch (error) {
            console.error('Error saving host status:', error);
            throw error;
        }
    }
}

// グローバルインスタンス
const api = new API();
