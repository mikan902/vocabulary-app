// IndexedDBラッパー
class VocabularyDB {
    constructor() {
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve();
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                // 私有単語ストア
                if (!db.objectStoreNames.contains(WORD_STORE)) {
                    const wordStore = db.createObjectStore(WORD_STORE, { keyPath: 'id', autoIncrement: true });
                    wordStore.createIndex('number', 'number', { unique: false });
                    wordStore.createIndex('english', 'english', { unique: false });
                }

                // テスト履歴ストア
                if (!db.objectStoreNames.contains(HISTORY_STORE)) {
                    const historyStore = db.createObjectStore(HISTORY_STORE, { keyPath: 'id', autoIncrement: true });
                    historyStore.createIndex('date', 'date', { unique: false });
                    historyStore.createIndex('wordId', 'wordId', { unique: false });
                }
            };
        });
    }

    // 私有単語の追加
    async addWord(word) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([WORD_STORE], 'readwrite');
            const store = transaction.objectStore(WORD_STORE);
            const request = store.add(word);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // 私有単語の取得（全件）
    async getAllWords() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([WORD_STORE], 'readonly');
            const store = transaction.objectStore(WORD_STORE);
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // 私有単語の更新
    async updateWord(word) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([WORD_STORE], 'readwrite');
            const store = transaction.objectStore(WORD_STORE);
            const request = store.put(word);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // 私有単語の削除
    async deleteWord(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([WORD_STORE], 'readwrite');
            const store = transaction.objectStore(WORD_STORE);
            const request = store.delete(id);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // テスト履歴の追加
    async addHistory(history) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([HISTORY_STORE], 'readwrite');
            const store = transaction.objectStore(HISTORY_STORE);
            const request = store.add(history);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // テスト履歴の取得（全件）
    async getAllHistory() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([HISTORY_STORE], 'readonly');
            const store = transaction.objectStore(HISTORY_STORE);
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // データのクリア（インポート用）
    async clearWords() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([WORD_STORE], 'readwrite');
            const store = transaction.objectStore(WORD_STORE);
            const request = store.clear();

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async clearHistory() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([HISTORY_STORE], 'readwrite');
            const store = transaction.objectStore(HISTORY_STORE);
            const request = store.clear();

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // バルクインサート（インポート用）
    async bulkAddWords(words) {
        const transaction = this.db.transaction([WORD_STORE], 'readwrite');
        const store = transaction.objectStore(WORD_STORE);
        
        for (const word of words) {
            store.add(word);
        }

        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }

    async bulkAddHistory(history) {
        const transaction = this.db.transaction([HISTORY_STORE], 'readwrite');
        const store = transaction.objectStore(HISTORY_STORE);
        
        for (const item of history) {
            store.add(item);
        }

        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }
}

// グローバルインスタンス
const db = new VocabularyDB();
