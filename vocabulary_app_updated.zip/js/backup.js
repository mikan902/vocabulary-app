// バックアップ機能
class BackupManager {
    constructor() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.getElementById('exportBtn').addEventListener('click', () => this.exportData());
        document.getElementById('importBtn').addEventListener('click', () => {
            document.getElementById('importFile').click();
        });
        document.getElementById('importFile').addEventListener('change', (e) => this.importData(e));
    }

    async exportData() {
        try {
            // 私有単語とテスト履歴を取得
            const words = await db.getAllWords();
            const history = await db.getAllHistory();

            const exportData = {
                version: 1,
                exportDate: new Date().toISOString(),
                words: words,
                history: history
            };

            // JSON形式でダウンロード
            const json = JSON.stringify(exportData, null, 2);
            const blob = new Blob([json], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `vocabulary-backup-${this.getDateString()}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            alert('バックアップを保存しました');
        } catch (error) {
            console.error('Export error:', error);
            alert('エクスポートに失敗しました');
        }
    }

    async importData(event) {
        const file = event.target.files[0];
        if (!file) return;

        try {
            const text = await file.text();
            const data = JSON.parse(text);

            // バージョンチェック
            if (!data.version || data.version !== 1) {
                alert('サポートされていないバックアップ形式です');
                return;
            }

            // 確認
            const wordCount = data.words ? data.words.length : 0;
            const historyCount = data.history ? data.history.length : 0;
            
            const message = `以下のデータをインポートします（既存データに追加）:\n` +
                          `・単語: ${wordCount}件\n` +
                          `・テスト履歴: ${historyCount}件\n\n` +
                          `よろしいですか？`;

            if (!confirm(message)) {
                // ファイル選択をリセット
                event.target.value = '';
                return;
            }

            // インポート実行（マージモード）
            let importedWords = 0;
            let importedHistory = 0;

            // 単語のインポート
            if (data.words && data.words.length > 0) {
                const existingWords = await db.getAllWords();
                const existingNumbers = new Set(existingWords.map(w => w.number));

                for (const word of data.words) {
                    // IDを除外して新規追加（重複番号チェック）
                    const { id, ...wordData } = word;
                    
                    if (!existingNumbers.has(wordData.number)) {
                        await db.addWord(wordData);
                        importedWords++;
                    }
                }
            }

            // テスト履歴のインポート
            if (data.history && data.history.length > 0) {
                for (const item of data.history) {
                    // IDを除外して新規追加
                    const { id, ...historyData } = item;
                    await db.addHistory(historyData);
                    importedHistory++;
                }
            }

            alert(`インポート完了\n単語: ${importedWords}件\nテスト履歴: ${importedHistory}件`);

            // ファイル選択をリセット
            event.target.value = '';

        } catch (error) {
            console.error('Import error:', error);
            alert('インポートに失敗しました。ファイル形式を確認してください。');
            event.target.value = '';
        }
    }

    getDateString() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        return `${year}${month}${day}-${hours}${minutes}`;
    }
}

// 初期化
let backupManager;
document.addEventListener('DOMContentLoaded', () => {
    backupManager = new BackupManager();
});
