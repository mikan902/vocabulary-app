// 管理者コード（環境変数として設定）
const ADMIN_CODE = 'admin123';

// データ構造の定義
const WORD_STORE = 'words';
const HISTORY_STORE = 'history';
const DB_NAME = 'VocabularyDB';
const DB_VERSION = 1;
