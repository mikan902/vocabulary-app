// 単語追加機能
class WordAdder {
    constructor() {
        this.form = document.getElementById('addWordForm');
        this.setupEventListeners();
        this.setNextNumber();
    }

    setupEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // スコープ変更時に番号を更新
        document.getElementById('wordScope').addEventListener('change', () => {
            this.setNextNumber();
        });
    }

    async setNextNumber() {
        const scope = document.getElementById('wordScope').value;
        let nextNumber = 1;

        if (scope === 'private') {
            // 私有単語の最大番号を取得
            const words = await db.getAllWords();
            if (words.length > 0) {
                const maxNumber = Math.max(...words.map(w => w.number));
                nextNumber = maxNumber + 1;
            }
        } else {
            // 共有単語の最大番号を取得
            const words = await api.getSharedWords();
            if (words.length > 0) {
                const maxNumber = Math.max(...words.map(w => w.number));
                nextNumber = maxNumber + 1;
            }
        }

        document.getElementById('wordNumber').value = nextNumber;
    }

    async handleSubmit(e) {
        e.preventDefault();

        const scope = document.getElementById('wordScope').value;
        const number = parseInt(document.getElementById('wordNumber').value);
        const english = document.getElementById('wordEnglish').value.trim();
        const japanese = document.getElementById('wordJapanese').value.trim();
        const example = document.getElementById('wordExample').value.trim();

        // 重複チェック
        if (scope === 'private') {
            const words = await db.getAllWords();
            const duplicate = words.find(w => w.number === number);
            if (duplicate) {
                if (!confirm(`番号 ${number} は既に使用されています。上書きしますか？`)) {
                    return;
                }
                // 上書き
                duplicate.english = english;
                duplicate.japanese = japanese;
                duplicate.example = example;
                await db.updateWord(duplicate);
                alert('単語を更新しました');
            } else {
                // 新規追加
                const word = { number, english, japanese, example };
                await db.addWord(word);
                alert('単語を追加しました');
            }
        } else {
            // 共有単語（ホストのみ）
            if (!auth.isHost) {
                alert('共有単語を追加するには管理者権限が必要です');
                return;
            }

            const words = await api.getSharedWords();
            const duplicate = words.find(w => w.number === number);
            
            if (duplicate) {
                if (!confirm(`番号 ${number} は既に使用されています。上書きしますか？`)) {
                    return;
                }
                // 上書き
                await api.updateSharedWord(duplicate.id, { number, english, japanese, example });
                alert('単語を更新しました');
            } else {
                // 新規追加
                await api.addSharedWord({ number, english, japanese, example });
                alert('単語を追加しました');
            }
        }

        // フォームをクリアして次の番号をセット
        document.getElementById('wordEnglish').value = '';
        document.getElementById('wordJapanese').value = '';
        document.getElementById('wordExample').value = '';
        
        await this.setNextNumber();
        
        // 番号欄にフォーカス
        document.getElementById('wordNumber').focus();
    }
}

// 初期化
let wordAdder;
document.addEventListener('DOMContentLoaded', () => {
    wordAdder = new WordAdder();
});
