// テスト機能
class TestManager {
    constructor() {
        this.currentTest = null;
        this.currentQuestionIndex = 0;
        this.testWords = [];
        this.results = [];
        
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.getElementById('startTestBtn').addEventListener('click', () => this.startTest());
        document.getElementById('showAnswerBtn').addEventListener('click', () => this.showAnswer());
        document.getElementById('correctBtn').addEventListener('click', () => this.judgeAnswer(true));
        document.getElementById('incorrectBtn').addEventListener('click', () => this.judgeAnswer(false));
        document.getElementById('quitTestBtn').addEventListener('click', () => this.quitTest());
        document.getElementById('backToSetupBtn').addEventListener('click', () => this.backToSetup());
    }

    async startTest() {
        const scope = document.getElementById('testScope').value;
        const start = parseInt(document.getElementById('testStart').value);
        const end = parseInt(document.getElementById('testEnd').value);
        const mode = document.getElementById('testMode').value;

        if (!start || !end) {
            alert('範囲を入力してください');
            return;
        }

        if (start > end) {
            alert('開始番号は終了番号以下にしてください');
            return;
        }

        // 単語を読み込み
        const privateWords = await db.getAllWords();
        const sharedWords = await api.getSharedWords();
        
        let allWords = [];
        if (scope === 'all' || scope === 'private') {
            allWords = allWords.concat(privateWords.map(w => ({ ...w, scope: 'private' })));
        }
        if (scope === 'all' || scope === 'shared') {
            allWords = allWords.concat(sharedWords.map(w => ({ ...w, scope: 'shared' })));
        }

        // 範囲でフィルター
        this.testWords = allWords.filter(w => w.number >= start && w.number <= end);

        if (this.testWords.length === 0) {
            alert('指定範囲に単語が見つかりません');
            return;
        }

        // シャッフル
        this.testWords = this.shuffleArray(this.testWords);

        // テスト開始
        this.currentTest = { mode, start, end, scope };
        this.currentQuestionIndex = 0;
        this.results = [];

        document.getElementById('testSetup').style.display = 'none';
        document.getElementById('testQuiz').style.display = 'block';
        document.getElementById('testResult').style.display = 'none';

        this.showQuestion();
    }

    showQuestion() {
        const word = this.testWords[this.currentQuestionIndex];
        const mode = this.currentTest.mode;

        // 進捗表示
        document.getElementById('quizProgress').textContent = 
            `${this.currentQuestionIndex + 1} / ${this.testWords.length}`;

        // 問題表示
        if (mode === 'en-ja') {
            document.getElementById('quizQuestion').textContent = word.english;
        } else {
            document.getElementById('quizQuestion').textContent = word.japanese;
        }

        // 答えを隠す
        document.getElementById('quizAnswer').classList.add('hidden');
        document.getElementById('showAnswerBtn').classList.remove('hidden');
        document.getElementById('judgmentBtns').classList.add('hidden');
    }

    showAnswer() {
        const word = this.testWords[this.currentQuestionIndex];
        const mode = this.currentTest.mode;

        // 答え表示
        if (mode === 'en-ja') {
            document.getElementById('answerText').textContent = word.japanese;
        } else {
            document.getElementById('answerText').textContent = word.english;
        }

        // 例文表示
        const exampleText = document.getElementById('exampleText');
        if (word.example) {
            exampleText.textContent = word.example;
            exampleText.style.display = 'block';
        } else {
            exampleText.style.display = 'none';
        }

        document.getElementById('quizAnswer').classList.remove('hidden');
        document.getElementById('showAnswerBtn').classList.add('hidden');
        document.getElementById('judgmentBtns').classList.remove('hidden');
    }

    async judgeAnswer(isCorrect) {
        const word = this.testWords[this.currentQuestionIndex];
        
        // 結果を記録
        this.results.push({
            wordId: word.id || word.number,
            wordScope: word.scope,
            word: word,
            isCorrect: isCorrect,
            timestamp: Date.now()
        });

        // 履歴をIndexedDBに保存
        await db.addHistory({
            wordId: word.id || word.number,
            wordScope: word.scope,
            number: word.number,
            english: word.english,
            japanese: word.japanese,
            mode: this.currentTest.mode,
            isCorrect: isCorrect,
            date: new Date().toISOString().split('T')[0],
            timestamp: Date.now()
        });

        // 次の問題へ
        this.currentQuestionIndex++;

        if (this.currentQuestionIndex < this.testWords.length) {
            this.showQuestion();
        } else {
            this.showResult();
        }
    }

    showResult() {
        const correctCount = this.results.filter(r => r.isCorrect).length;
        const incorrectCount = this.results.filter(r => !r.isCorrect).length;
        const total = this.results.length;
        const accuracy = total > 0 ? Math.round((correctCount / total) * 100) : 0;

        document.getElementById('testQuiz').style.display = 'none';
        document.getElementById('testResult').style.display = 'block';

        document.getElementById('correctCount').textContent = correctCount;
        document.getElementById('incorrectCount').textContent = incorrectCount;
        document.getElementById('accuracyRate').textContent = accuracy;
    }

    quitTest() {
        if (!confirm('テストを中止しますか？')) return;
        this.backToSetup();
    }

    backToSetup() {
        document.getElementById('testSetup').style.display = 'block';
        document.getElementById('testQuiz').style.display = 'none';
        document.getElementById('testResult').style.display = 'none';
        
        this.currentTest = null;
        this.currentQuestionIndex = 0;
        this.testWords = [];
        this.results = [];
    }

    shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }
}

// 初期化
let testManager;
document.addEventListener('DOMContentLoaded', () => {
    testManager = new TestManager();
});
