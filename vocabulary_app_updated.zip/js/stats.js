// 学習状況可視化
class StatsManager {
    constructor() {
        this.dailyChart = null;
        this.accuracyChart = null;
    }

    async renderStats() {
        await this.renderSummary();
        await this.renderDailyChart();
        await this.renderAccuracyChart();
    }

    async renderSummary() {
        // 総単語数
        const privateWords = await db.getAllWords();
        const sharedWords = await api.getSharedWords();
        const totalWords = privateWords.length + sharedWords.length;
        document.getElementById('totalWords').textContent = totalWords;

        // テスト履歴
        const history = await db.getAllHistory();
        
        // テスト回数（日ごとにカウント）
        const uniqueDates = new Set(history.map(h => h.date));
        document.getElementById('totalTests').textContent = uniqueDates.size;

        // 平均正答率
        if (history.length > 0) {
            const correctCount = history.filter(h => h.isCorrect).length;
            const avgAccuracy = Math.round((correctCount / history.length) * 100);
            document.getElementById('avgAccuracy').textContent = avgAccuracy + '%';
        } else {
            document.getElementById('avgAccuracy').textContent = '0%';
        }
    }

    async renderDailyChart() {
        const history = await db.getAllHistory();
        
        // 日別にテスト回数を集計
        const dailyCount = {};
        history.forEach(item => {
            const date = item.date;
            dailyCount[date] = (dailyCount[date] || 0) + 1;
        });

        // 日付順にソート
        const sortedDates = Object.keys(dailyCount).sort();
        const counts = sortedDates.map(date => dailyCount[date]);

        // グラフ描画
        const ctx = document.getElementById('dailyTestChart');
        
        if (this.dailyChart) {
            this.dailyChart.destroy();
        }

        this.dailyChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: sortedDates.map(date => this.formatDate(date)),
                datasets: [{
                    label: 'テスト回数',
                    data: counts,
                    backgroundColor: 'rgba(102, 126, 234, 0.6)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    async renderAccuracyChart() {
        const history = await db.getAllHistory();

        if (history.length === 0) {
            const ctx = document.getElementById('accuracyChart');
            if (this.accuracyChart) {
                this.accuracyChart.destroy();
            }
            return;
        }

        // 日別に正答率を集計
        const dailyStats = {};
        history.forEach(item => {
            const date = item.date;
            if (!dailyStats[date]) {
                dailyStats[date] = { correct: 0, total: 0 };
            }
            dailyStats[date].total++;
            if (item.isCorrect) {
                dailyStats[date].correct++;
            }
        });

        // 日付順にソート
        const sortedDates = Object.keys(dailyStats).sort();
        const accuracies = sortedDates.map(date => {
            const stats = dailyStats[date];
            return Math.round((stats.correct / stats.total) * 100);
        });

        // グラフ描画
        const ctx = document.getElementById('accuracyChart');
        
        if (this.accuracyChart) {
            this.accuracyChart.destroy();
        }

        this.accuracyChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: sortedDates.map(date => this.formatDate(date)),
                datasets: [{
                    label: '正答率 (%)',
                    data: accuracies,
                    backgroundColor: 'rgba(40, 167, 69, 0.2)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    formatDate(dateStr) {
        const date = new Date(dateStr);
        const month = date.getMonth() + 1;
        const day = date.getDate();
        return `${month}/${day}`;
    }
}

// 初期化
let statsManager;
document.addEventListener('DOMContentLoaded', () => {
    statsManager = new StatsManager();
});
