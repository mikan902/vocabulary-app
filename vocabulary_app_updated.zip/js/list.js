// 単語一覧機能
class WordList {
    constructor() {
        this.container = document.getElementById('wordListContainer');
        this.searchInput = document.getElementById('searchInput');
        this.scopeSelect = document.getElementById('listScope');
        this.sortSelect = document.getElementById('sortOrder');
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.searchInput.addEventListener('input', () => this.renderWords());
        this.scopeSelect.addEventListener('change', () => this.renderWords());
        this.sortSelect.addEventListener('change', () => this.renderWords());
    }

    async loadWords() {
        const privateWords = await db.getAllWords();
        const sharedWords = await api.getSharedWords();

        const formattedPrivate = privateWords.map(w => ({
            ...w,
            scope: 'private',
            displayId: w.id
        }));

        const formattedShared = sharedWords.map(w => ({
            ...w,
            scope: 'shared',
            displayId: w.id
        }));

        return [...formattedPrivate, ...formattedShared];
    }

    // 単語ごとの正答率をIndexedDB履歴から計算
    async loadAccuracyMap() {
        const history = await db.getAllHistory();
        const map = {};
        history.forEach(item => {
            const key = `${item.wordScope}-${item.number}`;
            if (!map[key]) {
                map[key] = { correct: 0, total: 0 };
            }
            map[key].total++;
            if (item.isCorrect) map[key].correct++;
        });
        return map;
    }

    async renderWords() {
        const [allWords, accuracyMap] = await Promise.all([
            this.loadWords(),
            this.loadAccuracyMap()
        ]);

        const searchTerm = this.searchInput.value.toLowerCase().trim();
        const scope = this.scopeSelect.value;
        const sortOrder = this.sortSelect.value;

        // スコープでフィルター
        let filtered = allWords;
        if (scope !== 'all') {
            filtered = filtered.filter(w => w.scope === scope);
        }

        // 検索でフィルター
        if (searchTerm) {
            filtered = filtered.filter(w => {
                return w.number.toString().includes(searchTerm) ||
                       w.english.toLowerCase().includes(searchTerm) ||
                       w.japanese.toLowerCase().includes(searchTerm);
            });
        }

        // 各単語に正答率情報を付与
        filtered = filtered.map(w => {
            const key = `${w.scope}-${w.number}`;
            const stat = accuracyMap[key] || null;
            const accuracy = stat ? Math.round((stat.correct / stat.total) * 100) : null;
            return { ...w, accuracy, stat };
        });

        // ソート
        if (sortOrder === 'number') {
            filtered.sort((a, b) => a.number - b.number);
        } else if (sortOrder === 'accuracy-asc') {
            // 正答率低い順（未テストは末尾）
            filtered.sort((a, b) => {
                if (a.accuracy === null && b.accuracy === null) return a.number - b.number;
                if (a.accuracy === null) return 1;
                if (b.accuracy === null) return -1;
                if (a.accuracy !== b.accuracy) return a.accuracy - b.accuracy;
                return a.number - b.number;
            });
        } else if (sortOrder === 'accuracy-desc') {
            // 正答率高い順（未テストは末尾）
            filtered.sort((a, b) => {
                if (a.accuracy === null && b.accuracy === null) return a.number - b.number;
                if (a.accuracy === null) return 1;
                if (b.accuracy === null) return -1;
                if (a.accuracy !== b.accuracy) return b.accuracy - a.accuracy;
                return a.number - b.number;
            });
        }

        // レンダリング
        if (filtered.length === 0) {
            this.container.innerHTML = '<p style="padding: 30px; text-align: center; color: #999;">単語が見つかりません</p>';
            return;
        }

        this.container.innerHTML = filtered.map(word => this.createWordHTML(word)).join('');
        this.attachWordEventListeners();
    }

    createWordHTML(word) {
        const scopeClass = word.scope === 'shared' ? 'scope-shared' : 'scope-private';
        const scopeText = word.scope === 'shared' ? '共有' : '私有';

        // 正答率バッジ
        let accuracyBadge = '';
        if (word.accuracy !== null) {
            let cls = 'accuracy-mid';
            if (word.accuracy >= 70) cls = 'accuracy-high';
            else if (word.accuracy < 40) cls = 'accuracy-low';
            const total = word.stat ? word.stat.total : 0;
            accuracyBadge = `<span class="word-accuracy ${cls}" title="${total}回テスト">${word.accuracy}%</span>`;
        } else {
            accuracyBadge = `<span class="word-accuracy accuracy-none">未テスト</span>`;
        }

        // 編集・削除ボタン
        const canEdit = word.scope === 'private' || (word.scope === 'shared' && auth.isHost);
        const editButtons = canEdit ? `
            <button class="btn btn-small btn-secondary edit-word" data-id="${word.displayId}" data-scope="${word.scope}">編集</button>
            <button class="btn btn-small btn-danger delete-word" data-id="${word.displayId}" data-scope="${word.scope}">削除</button>
        ` : '';

        return `
            <div class="word-item" data-id="${word.displayId}" data-scope="${word.scope}">
                <div class="word-left">
                    <span class="word-number">No.${word.number}</span>
                    <span class="word-scope ${scopeClass}">${scopeText}</span>
                    ${accuracyBadge}
                </div>
                <div class="word-center">
                    <span class="word-english">${this.escapeHtml(word.english)}</span>
                    <span class="word-sep">／</span>
                    <span class="word-japanese">${this.escapeHtml(word.japanese)}</span>
                    ${word.example ? `<span class="word-example">💬 ${this.escapeHtml(word.example)}</span>` : ''}
                </div>
                <div class="word-actions">
                    <button class="btn btn-small btn-primary speak-word" data-text="${word.english}">🔊</button>
                    ${editButtons}
                </div>
            </div>
        `;
    }

    attachWordEventListeners() {
        document.querySelectorAll('.speak-word').forEach(btn => {
            btn.addEventListener('click', () => {
                this.speak(btn.dataset.text);
            });
        });

        document.querySelectorAll('.edit-word').forEach(btn => {
            btn.addEventListener('click', () => {
                this.editWord(btn.dataset.id, btn.dataset.scope);
            });
        });

        document.querySelectorAll('.delete-word').forEach(btn => {
            btn.addEventListener('click', () => {
                this.deleteWord(btn.dataset.id, btn.dataset.scope);
            });
        });
    }

    speak(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'en-US';
            utterance.rate = 1.0;
            speechSynthesis.speak(utterance);
        } else {
            alert('お使いのブラウザは音声読み上げに対応していません');
        }
    }

    async editWord(id, scope) {
        const allWords = await this.loadWords();
        const word = allWords.find(w => w.displayId == id && w.scope === scope);
        if (!word) return;

        const newEnglish = prompt('英単語:', word.english);
        if (newEnglish === null) return;

        const newJapanese = prompt('日本語訳:', word.japanese);
        if (newJapanese === null) return;

        const newExample = prompt('例文:', word.example || '');
        if (newExample === null) return;

        const updatedWord = {
            ...word,
            english: newEnglish.trim(),
            japanese: newJapanese.trim(),
            example: newExample.trim()
        };

        try {
            if (scope === 'private') {
                await db.updateWord(updatedWord);
            } else {
                await api.updateSharedWord(id, {
                    number: updatedWord.number,
                    english: updatedWord.english,
                    japanese: updatedWord.japanese,
                    example: updatedWord.example
                });
            }
            alert('単語を更新しました');
            this.renderWords();
        } catch (error) {
            alert('更新に失敗しました');
        }
    }

    async deleteWord(id, scope) {
        if (!confirm('この単語を削除しますか？')) return;

        try {
            if (scope === 'private') {
                await db.deleteWord(parseInt(id));
            } else {
                await api.deleteSharedWord(id);
            }
            alert('単語を削除しました');
            this.renderWords();
        } catch (error) {
            alert('削除に失敗しました');
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// 初期化
let wordList;
document.addEventListener('DOMContentLoaded', () => {
    wordList = new WordList();
});
