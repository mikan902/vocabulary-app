// 復習機能（クイズ形式）
class ReviewManager {
    constructor() {
        this.reviewWords = [];
        this.currentIndex = 0;
        this.results = [];
        this.currentMode = 'en-ja';
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.getElementById('startReviewBtn').addEventListener('click', () => this.startReview());
        document.getElementById('showReviewAnswerBtn').addEventListener('click', () => this.showAnswer());
        document.getElementById('reviewCorrectBtn').addEventListener('click', () => this.judgeAnswer(true));
        document.getElementById('reviewIncorrectBtn').addEventListener('click', () => this.judgeAnswer(false));
        document.getElementById('quitReviewBtn').addEventListener('click', () => this.quitReview());
        document.getElementById('backToReviewSetupBtn').addEventListener('click', () => this.backToSetup());
    }

    async startReview() {
        const scope = document.getElementById('reviewScope').value;
        const countVal = document.getElementById('reviewCount').value;
        this.currentMode = document.getElementById('reviewMode').value;

        const history = await db.getAllHistory();

        if (history.length === 0) {
            alert('テスト履歴がありません。先にテストを受けてください。');
            return;
        }

        // 単語ごとに集計
        const wordStats = {};
        history.forEach(item => {
            const key = `${item.wordScope}-${item.number}`;
            if (!wordStats[key]) {
                wordStats[key] = {
                    word: item,
                    correct: 0,
                    total: 0,
                    lastAttempt: item.timestamp
                };
            }
            wordStats[key].total++;
            if (item.isCorrect) wordStats[key].correct++;
            if (item.timestamp > wordStats[key].lastAttempt) {
                wordStats[key].lastAttempt = item.timestamp;
            }
        });

        // スコープでフィルター
        let filtered = Object.values(wordStats);
        if (scope !== 'all') {
            filtered = filtered.filter(stat => stat.word.wordScope === scope);
        }

        if (filtered.length === 0) {
            alert('該当する単語がありません');
            return;
        }

        // 正答率の低い順にソート
        filtered.sort((a, b) => {
            const rateA = a.correct / a.total;
            const rateB = b.correct / b.total;
            if (rateA !== rateB) return rateA - rateB;
            return b.lastAttempt - a.lastAttempt;
        });

        // 件数を絞る
        const count = countVal === 'all' ? filtered.length : parseInt(countVal);
        const selected = filtered.slice(0, count);

        // word オブジェクトに変換
        this.reviewWords = selected.map(stat => ({
            id: stat.word.wordId,
            number: stat.word.number,
            english: stat.word.english,
            japanese: stat.word.japanese,
            example: stat.word.example || '',
            scope: stat.word.wordScope,
            accuracy: Math.round((stat.correct / stat.total) * 100)
        }));

        this.currentIndex = 0;
        this.results = [];

        // 画面切り替え
        document.getElementById('reviewSetup').style.display = 'none';
        document.getElementById('reviewQuiz').style.display = 'block';
        document.getElementById('reviewResult').style.display = 'none';

        this.showQuestion();
    }

    showQuestion() {
        const word = this.reviewWords[this.currentIndex];

        // 進捗
        document.getElementById('reviewProgress').textContent =
            `${this.currentIndex + 1} / ${this.reviewWords.length}`;

        // 問題
        if (this.currentMode === 'en-ja') {
            document.getElementById('reviewQuestion').textContent = word.english;
        } else {
            document.getElementById('reviewQuestion').textContent = word.japanese;
        }

        // 答えを隠す
        document.getElementById('reviewAnswer').classList.add('hidden');
        document.getElementById('showReviewAnswerBtn').classList.remove('hidden');
        document.getElementById('reviewJudgmentBtns').classList.add('hidden');
    }

    showAnswer() {
        const word = this.reviewWords[this.currentIndex];

        if (this.currentMode === 'en-ja') {
            document.getElementById('reviewAnswerText').textContent = word.japanese;
        } else {
            document.getElementById('reviewAnswerText').textContent = word.english;
        }

        const exampleEl = document.getElementById('reviewExampleText');
        if (word.example) {
            exampleEl.textContent = word.example;
            exampleEl.style.display = 'block';
        } else {
            exampleEl.style.display = 'none';
        }

        document.getElementById('reviewAnswer').classList.remove('hidden');
        document.getElementById('showReviewAnswerBtn').classList.add('hidden');
        document.getElementById('reviewJudgmentBtns').classList.remove('hidden');
    }

    async judgeAnswer(isCorrect) {
        const word = this.reviewWords[this.currentIndex];

        this.results.push({ word, isCorrect });

        // 履歴を保存
        await db.addHistory({
            wordId: word.id || word.number,
            wordScope: word.scope,
            number: word.number,
            english: word.english,
            japanese: word.japanese,
            mode: this.currentMode,
            isCorrect: isCorrect,
            date: new Date().toISOString().split('T')[0],
            timestamp: Date.now()
        });

        this.currentIndex++;
        if (this.currentIndex < this.reviewWords.length) {
            this.showQuestion();
        } else {
            this.showResult();
        }
    }

    showResult() {
        const correctCount = this.results.filter(r => r.isCorrect).length;
        const incorrectCount = this.results.filter(r => !r.isCorrect).length;
        const total = this.results.length;
        const accuracy = total > 0 ? Math.round((correctCount / total) * 100) : 0;

        document.getElementById('reviewQuiz').style.display = 'none';
        document.getElementById('reviewResult').style.display = 'block';

        document.getElementById('reviewCorrectCount').textContent = correctCount;
        document.getElementById('reviewIncorrectCount').textContent = incorrectCount;
        document.getElementById('reviewAccuracyRate').textContent = accuracy;
    }

    quitReview() {
        if (!confirm('復習を中止しますか？')) return;
        this.backToSetup();
    }

    backToSetup() {
        document.getElementById('reviewSetup').style.display = 'block';
        document.getElementById('reviewQuiz').style.display = 'none';
        document.getElementById('reviewResult').style.display = 'none';

        this.reviewWords = [];
        this.currentIndex = 0;
        this.results = [];
    }
}

// 初期化
let reviewManager;
document.addEventListener('DOMContentLoaded', () => {
    reviewManager = new ReviewManager();
});
