// メイン処理
class App {
    constructor() {
        this.currentPage = 'add';
        this.init();
    }

    async init() {
        // IndexedDBの初期化
        try {
            await db.init();
            console.log('Database initialized');
        } catch (error) {
            console.error('Failed to initialize database:', error);
            alert('データベースの初期化に失敗しました。ブラウザを更新してください。');
        }

        // タブ切り替えのイベントリスナー
        this.setupTabNavigation();

        // 認証UIの初期化
        auth.updateUI();

        // 初期ページの表示
        this.showPage('add');
    }

    setupTabNavigation() {
        const tabButtons = document.querySelectorAll('.tab-btn');
        
        tabButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const page = btn.dataset.page;
                this.showPage(page);
            });
        });
    }

    async showPage(pageName) {
        // すべてのページを非表示
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });

        // すべてのタブボタンを非アクティブ
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        // 指定されたページを表示
        const targetPage = document.getElementById(`page-${pageName}`);
        if (targetPage) {
            targetPage.classList.add('active');
        }

        // 対応するタブボタンをアクティブ
        const targetBtn = document.querySelector(`.tab-btn[data-page="${pageName}"]`);
        if (targetBtn) {
            targetBtn.classList.add('active');
        }

        // ページごとの処理
        this.currentPage = pageName;
        await this.handlePageLoad(pageName);
    }

    async handlePageLoad(pageName) {
        switch (pageName) {
            case 'add':
                // 次の番号をセット
                if (wordAdder) {
                    await wordAdder.setNextNumber();
                }
                break;
            
            case 'list':
                // 単語一覧を表示
                if (wordList) {
                    await wordList.renderWords();
                }
                break;
            
            case 'test':
                // テスト設定画面に戻す
                if (testManager) {
                    testManager.backToSetup();
                }
                break;
            
            case 'review':
                // 復習リストをクリア（ボタンを押したら表示）
                document.getElementById('reviewList').innerHTML = '';
                break;
            
            case 'stats':
                // 学習状況を描画
                if (statsManager) {
                    await statsManager.renderStats();
                }
                break;
            
            case 'backup':
                // 特に処理なし
                break;
        }
    }
}

// アプリケーションの起動
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new App();
});

// ページ離脱時の警告（テスト中のみ）
window.addEventListener('beforeunload', (e) => {
    if (testManager && testManager.currentTest) {
        e.preventDefault();
        e.returnValue = '';
    }
});
